# ai_assignment
#template consists of web app in a generic manner 
#app.py has the interface along with my API key , do not use my API key and create your own using the link <https://platform.openai.com/api-keys>
#Also make sure you make your own webpage . 
#This is a private repository and access will be granted on a one to one basis .
<img width="731" alt="Screenshot 2023-11-26 at 3 30 27 PM" src="https://github.com/sahilsanskarjha12/ai_assignment/assets/140010456/e17dc660-0402-4fe1-87fe-0b8362942176">
